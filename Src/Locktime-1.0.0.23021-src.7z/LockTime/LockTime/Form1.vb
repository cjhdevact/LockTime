﻿Public Class Form1

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        Label1.Text = Format(Now(), "HH:mm:ss")
    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim mw As Integer = SystemInformation.PrimaryMonitorSize.Width
        Timer1.Enabled = True

        Dim a As New System.Drawing.Point
        a.X = 0
        a.Y = 0
        Me.Location = a
    End Sub


    Private Sub ext_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ext.Click
        End
    End Sub
End Class
